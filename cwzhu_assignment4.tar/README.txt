In this .tar should be included:

	-cwzhu_Assignment4Report.pdf
	-README.txt
	-iris.data
	-iris.out
	-winequality-white.data
	-winequality-white.out
	-Java Source Files
		-Kmeans.java
		-DataRecords.java
		-RunKmeans.java
	
To compile, enter the following on the command line: 

	javac DataRecords.java Kmeans.java RunKmeans.java

To run, run RunKmeans with the following parmeters on the command line:
	
	java RunKmeans [data file path] [output file path] ["delimiter"] [K] [threshold of centroid movement]
	
	data file path - the path of the data file
	output file path - the path of the output file
	delimiter - the string used to separate attributes in a record
	K - the number of centroids / clusters
	threshold of centroid movement - the maximum euclidean distance allowed between any centroid's current 
		and previous location. Once the threshold is satisfied, the algorithm stops converging. 
		
	For example:
	java RunKmeans winequality-white.csv winequality-white.out ";" 2 .001
	
*NOTE: If you want to use other data files, remove any non-numerical data such as attribute names or 
class labels. Class labels should always be removed because they may interfere with the clustering results. 

	
	
	