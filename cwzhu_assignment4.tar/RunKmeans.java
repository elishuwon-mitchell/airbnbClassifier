/*THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING

A TUTOR OR CODE WRITTEN BY OTHER STUDENTS - Colvin Zhu
*/


import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
//import java.util.ArrayList;
import java.util.Arrays;
//import java.util.HashSet;
import java.util.List;
//import java.util.Set;

public class RunKmeans {
	private static String dataFile;
	private static String outFile;
	private static String delimiter;
	private static int K;
	private static double threshold;
	private static DataRecords data; 
	
	public static double WSS(List<List<Integer>> clusters, double[][] centroids) {
		double wss = 0;
		double[] mi;
		double[] record;
		double dist;
		
		for (int i=0; i<clusters.size(); i++){
			mi = centroids[i];
			for (int x=0; x<clusters.get(i).size(); x++){
				record = data.getRecord(clusters.get(i).get(x));
				dist = 0;
				for (int attr=0; attr<mi.length; attr++){
					dist += Math.pow(record[attr] - mi[attr], 2);
				}
				wss += dist;
			}
		}
		
		return wss;
	}
	
	public static double BSS(double[][] centroids) {
		double bss = 0;
		
		for (int i=0; i<centroids.length; i++){
			for (int j=0; j<centroids.length; j++){
				for (int attr=0; attr<centroids[i].length; attr++)
				bss += Math.pow((centroids[i][attr] - centroids[j][attr]), 2);
			}
		}
		
		return bss;
	}
	
	public static double TSS(List<List<Integer>> clusters, double[][] centroids){
		return WSS(clusters, centroids) + BSS(centroids);
	}
	
	public static void main(String[] args) throws IOException {
		if (args.length <= 5) {
			if (args.length == 3){
				dataFile = args[0];
				outFile = args[1];
				delimiter = args[2];
			}else if (args.length == 5){
				dataFile = args[0];
				outFile = args[1];
				delimiter = args[2];
				K = Integer.parseInt(args[3]);
				threshold = Double.parseDouble(args[4]);
			}
			else{
				System.err.println("Usage:\nDataFilePath: /Users/username/documents/iris.csv"
					+ "\nOutFilePath: /Users/username/documents/iris.out"
					+ "\nK: 2"
					+ "\ndelimiter: \",\""
					+ "\nthreshold: .001");
				System.exit(0);
			}
		}
		
		data = new DataRecords (dataFile, delimiter);
		Kmeans kmeans = new Kmeans(data, K, threshold);
		List<List<Integer>> clusters = kmeans.cluster();
		
		double wss = WSS(clusters, kmeans.getCentroids());
		double bss = BSS(kmeans.getCentroids());
		double tss = bss + wss;
		
		FileOutputStream fstream = new FileOutputStream(outFile);
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fstream));
		
		for (int c=0; c<clusters.size(); c++) {
			writer.write("*****CLUSTER " + (c+1) + "*****\n");
			for (Integer recordID : clusters.get(c)) {
				//writer.write(Arrays.toString(data.getRecord(recordID)) + "\tClass: " + data.getClass(recordID) + "\n");
				writer.write(Arrays.toString(data.getRecord(recordID)) + "\n");
			}
			writer.write("\n");
		}
		
		writer.write("*****PERFORMANCE METRICS*****\n");
		writer.write("K: " + K + "\n");
		writer.write("WSS (Within Cluster Sum of Squared Errors): " + wss + "\n");
		writer.write("BSS (Between Cluster Sum of Squared Errors): " +  bss + "\n");
		writer.write("TSS (Total Sum of Squared Errors): " + tss + "\n");
		
		writer.close();
		fstream.close();
	}
}
