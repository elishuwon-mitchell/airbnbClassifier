/*THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING

A TUTOR OR CODE WRITTEN BY OTHER STUDENTS - Colvin Zhu

Based on AbstractKMeans.java by Jinho D. Choi: 
https://github.com/emory-courses/cs325/blob/master/src/main/java/edu/emory/mathcs/cs325/document/AbstractKmeans.java
*/


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Kmeans {
	DataRecords dataModel;
	int K;
	double threshold;
	double[][] centroids;
	
	public Kmeans (DataRecords data, int k, double threshold){
		setDataModel(data);
		setK(k);
		setThreshold(threshold);
		setCentroids(initCentroids());
	}

	public List<List<Integer>> cluster() {
		double[][] prevCentroids;
		List<List<Integer>> clusters;
		
		do{
			clusters = maximize(centroids);
			prevCentroids = centroids;
			centroids = expect(clusters);
		}while(centroidDistance(prevCentroids, centroids) > threshold);
		
		return clusters;
	}
	
	public double[][] initCentroids() {
		double[][] centroids = new double[K][];
		Set<Integer> chosenIDs = new HashSet<Integer>();
		int maxID = dataModel.getNumRecords();
		int id;
		Random rand = new Random();
		int i = 0;
		
		while (i < centroids.length){
			id = rand.nextInt(maxID);
			if (!chosenIDs.contains(id)){
				chosenIDs.add(id);
				centroids[i++] = dataModel.getRecord(id);
			}
		}
		
		return centroids;
	}
	
	public double[][] expect (List<List<Integer>> clusters) {
		int numAttr = dataModel.getNumAttr();
		double[][] centroids = new double[clusters.size()][numAttr];
		double[] record;
		
		for (int c=0; c<clusters.size(); c++){
			for (int r=0; r<clusters.get(c).size(); r++){
				record = dataModel.getRecord(clusters.get(c).get(r)); 
				for (int attr=0; attr<numAttr; attr++){
					centroids[c][attr] += record[attr];
				}
			}
		}
		
		for (int c=0; c<centroids.length; c++){
			for (int attr=0; attr<centroids[c].length; attr++){
				centroids[c][attr] /= clusters.get(c).size();
			}
		}
		
		return centroids;
	}
	
	public double centroidDistance (double[][] centroidA, double[][] centroidB) {
		double maxSum = 0;
		double sum = 0;
		
		for (int c=0; c<centroidA.length; c++){
			sum = 0;
			for (int attr=0; attr<centroidA[c].length; attr++){
				sum += Math.pow(centroidB[c][attr]-centroidA[c][attr], 2);
			}
		}
		
		if (sum > maxSum){
			maxSum = sum;
		}
		
		return Math.sqrt(maxSum);
	}
	
	public List<List<Integer>> maximize (double[][] centroids) {
		List<List<Integer>> clusters = new ArrayList<List<Integer>>();
		for (int c=0; c<K; c++){
			clusters.add(new ArrayList<Integer>());
		}
		
		int numRecords = dataModel.getNumRecords();
		double[] record;
		double min, dist;
		int clusID = 0;
		
		for (int i=0; i<numRecords; i++){
			record = dataModel.getRecord(i);
			min = distance(centroids[0], record);
			clusID = 0;
			
			for (int j=1; j<K; j++){
				dist = distance(centroids[j], record);
				if (dist < min){
					min = dist;
					clusID = j;
				}
			}
			
			clusters.get(clusID).add(i); 
		}
		
		return clusters;
	}
	
	public double distance(double[] centroid, double[] record) {
		double sum = 0;
		
		for (int i=0; i<centroid.length; i++){
			sum += Math.pow((record[i] - centroid[i]), 2);
		}
		
		return Math.sqrt(sum);
	}

	public DataRecords getDataModel() {
		return dataModel;
	}

	public void setDataModel(DataRecords dataModel) {
		this.dataModel = dataModel;
	}

	public int getK() {
		return K;
	}

	public void setK(int k) {
		K = k;
	}
	
	public double getThreshold() {
		return threshold;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}
	
	
	public double[][] getCentroids() {
		return centroids;
	}

	public void setCentroids(double[][] centroids) {
		this.centroids = centroids;
	}
}
