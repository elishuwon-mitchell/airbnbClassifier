/*THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING

A TUTOR OR CODE WRITTEN BY OTHER STUDENTS - Colvin Zhu*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/*
 * Data model to access dataset file
 * 		Attributes: labeled as id's 0 to (number of attributes-1)
 * 			first column is skipped because it is the class label
 * 		Records: labeled as id's 0 to (number of records-1)
 */
public class DataRecords {
	private String filePath;
	private int numAttr;
	private String delimiter;
	
	public DataRecords (String filePath, String delimiter) {
		setFilePath(filePath);
		
		try{
			BufferedReader bReader = new BufferedReader(new FileReader(filePath));
			String s = bReader.readLine();
			setDelimiter(delimiter);
			String[] sArray = s.split(delimiter);
			numAttr = sArray.length;	
			
			bReader.close();
		}catch(IOException e){
			System.out.println(e.getMessage());
			numAttr = -1;
		}
	}

	/*
	 * get record from file as a Record object
	 */
	public double[] getRecord (int id) {
		String s = null;
		try{
			BufferedReader bReader = new BufferedReader(new FileReader(filePath));
			for (int i=0; i<=id; i++){
				s = bReader.readLine();
			}
			bReader.close();
		}catch (IOException e){
			System.out.println(e.getMessage());
			return null;
		}
		if (s == null) return null;
		
		String[] sArray = s.split(delimiter);
		double[] record = new double[sArray.length];
		for (int i=0; i<sArray.length; i++){
			record[i] = Double.parseDouble(sArray[i]);
		}
		
		return record;
	}
	
	/*public String getClass (int id) {
		String s = null;
		try{
			BufferedReader bReader = new BufferedReader(new FileReader(filePath));
			for (int i=0; i<=id; i++){
				s = bReader.readLine();
			}
			bReader.close();
		}catch (IOException e){
			System.out.println(e.getMessage());
			return null;
		}
		if (s == null) return null;
		
		String[] sArray = s.split("delimiter");
		return sArray[sArray.length-1];
	}*/
	
	//get attribute value of record
	public double getAttrValue (int id, int attr) {
		return getRecord(id)[attr];
	}
	
	public int getNumRecords() {	
		int count = 0;
		try{
			BufferedReader bReader = new BufferedReader(new FileReader(filePath));
			String s = bReader.readLine();
			while(s!=null && !"".equals(s)){
				count++;
				s = bReader.readLine();
			}
			bReader.close();
			return count;
		}catch (IOException e){
			System.out.println(e.getMessage());
			return -1;
		}
	}
	
	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public int getNumAttr() {
		return numAttr;
	}

	public void setNumAttr(int numAttr) {
		this.numAttr = numAttr;
	}
	
	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
}
